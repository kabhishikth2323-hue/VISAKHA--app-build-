VISAKHA WEBSITE

1. Extract the VISAKHA_website.zip file.
2. Open the folder and tap/click index.html.
3. Choose Chrome or another modern browser.
4. Keep the assets folder next to index.html; it contains all your uploaded media.

This is a local website package. To publish it online, upload the whole extracted folder to a static hosting service.
